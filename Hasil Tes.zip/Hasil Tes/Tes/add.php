<html>
<head>
    <title>Add Users</title>
</head>

<body>
    <a href="index.php">Go to Home</a>
    <br/><br/>

    <form action="add.php" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td>Kode Barang</td>
                <td><input type="text" name="kb"></td>
            </tr>
            <tr> 
                <td>Nama Barang</td>
                <td><input type="text" name="nb"></td>
            </tr>
            <tr> 
                <td>Harga Jual</td>
                <td><input type="text" name="hj"></td>
            </tr>
              <tr> 
                <td>Harga Beli</td>
                <td><input type="text" name="hb"></td>
            </tr>
                 <tr> 
                <td>Satuan</td>
                <td><input type="text" name="sa"></td>
            </tr>
                 <tr> 
                <td>Kategori</td>
                <td><input type="text" name="kt"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
        </table>
    </form>

    <?php

    // Check If form submitted, insert form data into users table.
    if(isset($_POST['Submit'])) {
        $kb = $_POST['kb'];
        $nb = $_POST['nb'];
        $hj = $_POST['hj'];
        $hb = $_POST['hb'];
        $sa = $_POST['sa'];
        $kt = $_POST['kt'];

        // include database connection file
        include_once("config.php");

        // Insert user data into table
        $result = mysqli_query($mysqli, "INSERT INTO `barang`(KB,NB,HJ,HB,SA,KT) VALUES('$kb','$nb','$hj','$hb','$sa','$kt')");

        // Show message when user added
        echo "User added successfully. <a href='index.php'>View Users</a>";
    }
    ?>
</body>
</html>