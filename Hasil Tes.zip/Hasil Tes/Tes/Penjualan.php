<html>
<head>
   
</head>

<body>
    <a href="index.php">Master Barang</a>
     <a href="Tampilpenjualan.php">Data Penjualan</a>
    <br/><br/>

    <form action="Penjualan.php" method="post" name="form2">
        <table width="25%" border="0">
            <tr> 
                <td>Tgl Faktur</td>
                <td><input type="text" name="tf"></td>
            </tr>
            <tr> 
                <td>No Faktur</td>
                <td><input type="text" name="nf"></td>
            </tr>
            <tr> 
                <td>Nama Konsumen</td>
                <td><input type="text" name="nm"></td>
            </tr>
              <tr> 
                <td>Kode barang</td>
                <td><input type="text" name="kb"></td>
            </tr>
                 <tr> 
                <td>Jumlah</td>
                <td><input type="text" name="ju"></td>
            </tr>
                 <tr> 
                <td>Harga satuan</td>
                <td><input type="text" name="hs"></td>
            </tr>
              </tr>
                 <tr> 
                <td>Harga Total</td>
                <td><input type="text" name="ht"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Simpan"></td>
            </tr>
        </table>
    </form>

    <?php

    // Check If form submitted, insert form data into users table.
    if(isset($_POST['Submit'])) {
        $name = $_POST['tf'];
        $email = $_POST['nf'];
        $mobile = $_POST['nm'];
        $hb = $_POST['kb'];
        $sa = $_POST['ju'];
        $kt = $_POST['hs'];
        $ht = $_POST['ht'];

        // include database connection file
        include_once("config.php");

        // Insert user data into table
        $result = mysqli_query($mysqli, "INSERT INTO `penjualan`(TF,NF,KB,KB,JU,HS,HT) VALUES('$name','$email','$mobile','$hb','$sa','$kt','$ht')");

        // Show message when user added
        echo "User added successfully. <a href='Tampilpenjualan.php'>View Users</a>";
    }
    ?>
    </table>
</body>
</html>