<?php
// Create database connection using config file
include_once("config.php");

// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM barang ORDER BY id ASC");
?>

<html>
<head>    
    <title>Homepage</title>
</head>

<body>
<a href="Penjualan.php">Page Penjualan</a>  <br/><br/>
<a href="add.php">Add Barang</a>            <br/><br/>

    <table width='80%' border=1>

    <tr>
        <th>Kode Barang</th> <th>Nama Barang</th> <th>Harga Jual</th> <th>Harga Beli</th> <th>Satuan</th> <th>Kategori</th> <th>Update</th>
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['KB']."</td>";
        echo "<td>".$user_data['NB']."</td>";    
        echo "<td>".$user_data['HJ']."</td>";
        echo "<td>".$user_data['HB']."</td>";
        echo "<td>".$user_data['SA']."</td>";
        echo "<td>".$user_data['KT']."</td>";
        echo "<td><a href='edit.php?id=$user_data[id]'>Edit</a> | <a href='delete.php?id=$user_data[id]'>Delete</a></td></tr>";        
    }
    ?>
    </table>
</body>
</html>