<?php
// Create database connection using config file
include_once("config.php");

// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM `penjualan` ORDER BY No ASC");
?>

<html>
<head>    
    <title>Homepage</title>
</head>

<body>
<a href="Penjualan.php">Page Penjualan</a>  <br/><br/>
<a href="index.php">Master Barang</a>            <br/><br/>

    <table width='80%' border=1>

    <tr>
        <th>Tgl Faktur</th> <th>No Faktur</th> <th>Nama Konsumen</th> <th>Kode barang</th> <th> Jumlah</th> <th>Harga satuan</th> <th>Harga Total</th> <th>Update</th>
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['TF']."</td>";
        echo "<td>".$user_data['NF']."</td>";    
        echo "<td>".$user_data['NM']."</td>";
        echo "<td>".$user_data['KB']."</td>";
        echo "<td>".$user_data['JU']."</td>";
        echo "<td>".$user_data['HS']."</td>";
        echo "<td>".$user_data['HT']."</td>";
        echo "<td><a href='edit.php?id=$user_data[No]'>Edit</a> | <a href='delete.php?id=$user_data[No]'>Delete</a></td></tr>";        
    }
    ?>
    </table>
</body>
</html>