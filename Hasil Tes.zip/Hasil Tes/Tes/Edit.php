<?php
// include database connection file
include_once("config.php");

// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{   
    $id = $_POST['id'];

    $kb=$_POST['KB'];
    $nb=$_POST['NB'];
    $hj=$_POST['HJ'];
    $hb=$_POST['HB'];
    $sa=$_POST['SA'];
    $kt=$_POST['KT'];

    // update user data
    $result = mysqli_query($mysqli, "UPDATE barang SET KB='$kb',NB='$nb',HJ='$hj',HB='$hb',SA='$sa',KT='$kt' WHERE id=$id");

    // Redirect to homepage to display updated user in list
    header("Location: index.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];

// Fetech user data based on id
$result = mysqli_query($mysqli, "SELECT * FROM barang WHERE id=$id");

while($user_data = mysqli_fetch_array($result))
{
    $kb = $user_data['KB'];
    $nb = $user_data['NB'];
    $hj = $user_data['HJ'];
    $hb = $user_data['HB'];
    $sa = $user_data['SA'];
    $kt = $user_data['KT'];
}
?>
<html>
<head>  
    <title>Edit User Data</title>
</head>

<body>
    <a href="index.php">Home</a>
    <br/><br/>

    <form KB="update_user" method="post" action="edit.php">
        <table border="0">
            <tr> 
                <td>Kode Barang</td>
                <td><input type="text" name="KB" value=<?php echo $kb;?>></td>
            </tr>
              <tr> 
                <td>Nama Barang</td>
                <td><input type="text" name="NB" value=<?php echo $nb;?>></td>
            </tr>

               <tr> 
                <td>Harga Jual</td>
                <td><input type="text" name="HJ" value=<?php echo $hj;?>></td>
            </tr>
               <tr> 
                <td>Harga Beli</td>
                <td><input type="text" name="HB" value=<?php echo $hb;?>></td>
            </tr>
                <tr> 
                <td>Satuan</td>
                <td><input type="text" name="SA" value=<?php echo $sa;?>></td>
            </tr>
               <tr> 
                <td>Kategori</td>
                <td><input type="text" name="KT" value=<?php echo $kt;?>></td>
            </tr>
          
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>